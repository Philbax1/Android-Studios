package com.example.artquiz_assessment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity
{
    private TextView mFinalScore;
    private Button mToMainMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        /*
        Intent intent = getIntent();
        final String mScore = intent.getStringExtra("finalScore");
*/

        mFinalScore.setText("You scored/n" + 10 + "/10");

        mToMainMenu = (Button)findViewById(R.id.backToMain);


        mToMainMenu.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                openMenu();
            }
        });

    }

    public void openMenu()
    {  //use of intents

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}
