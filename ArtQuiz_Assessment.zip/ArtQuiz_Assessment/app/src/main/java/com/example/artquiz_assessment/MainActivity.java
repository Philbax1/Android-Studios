package com.example.artquiz_assessment;
/*https://www.youtube.com/watch?v=4g1_UH_6VQc*/

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/**
 * App runs a menu system that either quits program or loads second activity the quiz.
 */

public class MainActivity extends AppCompatActivity {

    private Button mOpenQuiz;
    private Button mExitProgram;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mOpenQuiz = (Button)findViewById(R.id.openQuiz);
        mExitProgram = (Button)findViewById(R.id.Quit);

        mOpenQuiz.setOnClickListener(new View.OnClickListener() { //opens activity 2
            @Override
            public void onClick(View v) {
                openActivity2();
            }
        });

        mExitProgram.setOnClickListener(new View.OnClickListener() { //exits program
            @Override
            public void onClick(View v)
            {
                finish();
                System.exit(0);
            }
        });
    }

    public void openActivity2(){ //use of intents
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }

}
