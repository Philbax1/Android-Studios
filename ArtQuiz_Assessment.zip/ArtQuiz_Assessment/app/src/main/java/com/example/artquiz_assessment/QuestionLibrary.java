package com.example.artquiz_assessment;

public class QuestionLibrary {

    private String mQuestions [] = { //library of questions to be passed to activity2
            "Which of the following is not a famous artist?",
            "Which physical appearance was Salvador Dali known for?",
            "Which nationality was the artist Francis Bacon?",
            "Edvard Munch's the Scream was done in which style?",
            "Which film depicted whistler's mother with alterations?",
            "Which artist painted The Last Supper?",
            "The masterpiece Mona Lisa was a portrait of?",
            "Flemish artist Peter Paul Rubens was born where?",
            "Which year did Vincent Van Gogh create The Starry Night?",
            "According to Google how much is the painting \"Salvator Mundi\" worth?",
            //"See Total Score",
    };

    private String mChoices [][] = { //library of answers to be passed to activity2
            {"Vincent Van Gogh", "Andy Warhol", "Salvator Bali"},
            {"Moustache", "Hairstyle", "Eyes"},
            {"American", "Italian", "English"},
            {"Expressionism", "Surrealism", "Cubism"},
            {"Bean", "Misery", "Home Alone"},
            {"Michelangelo", "Leonardo da Vinci", "Pablo Picasso"},
            {"Mona Lisa", "Elizabeth Mona", "Lisa Gherardini"},
            {"Siegen, Germany", "Rome, Italy", "Valensole, France"},
            {"1889", "1843", "1905"},
            {"100.1 Million", "250.7 Million", "450.3 Million"},
            //{"Yes", "No", ""},
    };

    //library of correct answers to be passed to activity2
    private String mCorrectAnswers [] = {"Salvator Bali", "Moustache", "English", "Expressionism", "Bean",
            "Leonardo da Vinci", "Lisa Gherardini", "Siegen, Germany", "1889", "450.3 Million"/*, "Yes"*/};


    //Gets and sets

    public String getQuestion(int a){
        String question = mQuestions[a];
        return question;
    }

    public String getChoice1(int a){
        String choice0 = mChoices[a][0];
        return choice0;
    }

    public String getChoice2(int a){
        String choice1 = mChoices[a][1];
        return choice1;
    }

    public String getChoice3(int a){
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getCorrectAnswer(int a){
        String answer = mCorrectAnswers[a];
        return answer;
    }

}