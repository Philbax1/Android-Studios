package com.example.artquiz_assessment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    private QuestionLibrary mQuestionLibrary = new QuestionLibrary();

    private TextView mScoreView;
    private TextView mQuestionView;
    private Button mButtonChoice1;
    private Button mButtonChoice2;
    private Button mButtonChoice3;
    private Button mExitProgram;

    private String mAnswer;
    private int mScore = 0;
    private int mQuestionNumber = 0;

    // goes back to main menu
    public int numForFinalScore = 0;
    public final int numQuestions = 10;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        mScoreView = (TextView)findViewById(R.id.score);
        mQuestionView = (TextView)findViewById(R.id.question);
        mButtonChoice1 = (Button)findViewById(R.id.choice1);
        mButtonChoice2 = (Button)findViewById(R.id.choice2);
        mButtonChoice3 = (Button)findViewById(R.id.choice3);
        mExitProgram = (Button)findViewById(R.id.Quit);

        updateQuestion();

        //Start of button listener Button
        mButtonChoice1.setOnClickListener(new View.OnClickListener() //button saves users guesses
        {
            @Override
            public void onClick(View view)
            {
                numForFinalScore++;

                if (numForFinalScore == numQuestions)
                {
                    openActivity1();
                }

                    if (mButtonChoice1.getText() == mAnswer) {
                        mScore = mScore + 1;
                        updateScore(mScore);

                        Toast.makeText(MainActivity2.this, mAnswer + " is Correct", Toast.LENGTH_SHORT).show();
                        updateQuestion();
                    } else {
                        Toast.makeText(MainActivity2.this, "Wrong, correct answer is " + mAnswer, Toast.LENGTH_SHORT).show();
                        updateQuestion();
                    }
            }
        });

        mButtonChoice2.setOnClickListener(new View.OnClickListener() {  //button saves users guesses
            @Override
            public void onClick(View view)
            {
                numForFinalScore++;

                if (numForFinalScore == numQuestions)
                {
                    openActivity1();
                }

                if (mButtonChoice2.getText() == mAnswer){
                    mScore = mScore + 1;
                    updateScore(mScore);

                    Toast.makeText(MainActivity2.this,mAnswer + " is Correct", Toast.LENGTH_SHORT).show();
                    updateQuestion();
                }else{
                    Toast.makeText(MainActivity2.this,"Wrong, correct answer is " + mAnswer, Toast.LENGTH_SHORT).show();
                    updateQuestion();
                }

            }
        });

        mButtonChoice3.setOnClickListener(new View.OnClickListener()  //button saves users guesses
        {
            @Override
            public void onClick(View view)
            {
                numForFinalScore++;

                if (numForFinalScore == numQuestions)
                {
                    openActivity1();
                }

                if (mButtonChoice3.getText() == mAnswer){
                    mScore = mScore + 1;
                    updateScore(mScore);

                    Toast.makeText(MainActivity2.this,mAnswer + " is Correct", Toast.LENGTH_SHORT).show();
                    updateQuestion();
                }else{
                    Toast.makeText(MainActivity2.this,"Wrong, correct answer is " + mAnswer, Toast.LENGTH_SHORT).show();
                    updateQuestion();
                }

            }
        });

    }

    private void updateQuestion() //updates the question and the potential answers
    {
        mQuestionView.setText(mQuestionLibrary.getQuestion(mQuestionNumber));
        mButtonChoice1.setText(mQuestionLibrary.getChoice1(mQuestionNumber));
        mButtonChoice2.setText(mQuestionLibrary.getChoice2(mQuestionNumber));
        mButtonChoice3.setText(mQuestionLibrary.getChoice3(mQuestionNumber));

        mAnswer = mQuestionLibrary.getCorrectAnswer(mQuestionNumber);
        mQuestionNumber++;
    }

    private void updateScore(int point) //adds one to score total
    {
        mScoreView.setText("" + mScore);
    }

    public void openActivity1() //use of intents
    {
        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        i.putExtra("finalScore", mScore);

        Intent intent4 = new Intent(this, MainActivity.class);
        startActivity(intent4);
    }

}
